import Quiz from '../../client/src/components/Quiz';

describe('Quiz Component', () => {
  it('renders the Quiz component', () => {
    cy.mount(<Quiz />);
    cy.contains('Start Quiz').should('exist'); // Verify the Start Quiz button exists
  });

  it('starts the quiz when the button is clicked', () => {
    cy.mount(<Quiz />);
    cy.contains('Start Quiz').click();
    cy.get('.question').should('exist'); // Verify a question is rendered
  });
});
